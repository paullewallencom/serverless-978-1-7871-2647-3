# Usage

Before running the frontend examples, you need to deploy the backend (running `serverless deploy`) and replace the frontend API address (inside `src/components/app.js`) with your deployed backend address.

The frontend is a Create-React-App. Run `npm install` to install and `npm start` to execute.
