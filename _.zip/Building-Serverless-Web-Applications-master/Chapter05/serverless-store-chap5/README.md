# Configuration files

**Frontend**: src/lib/config
