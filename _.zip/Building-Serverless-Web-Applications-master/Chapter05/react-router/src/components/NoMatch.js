import React, { Component } from 'react';

class NoMatch extends Component {
    render() {
        return (
            <div className="row">
                <div className="col-md-12">
                    <h4>Page not found</h4>
                </div>
            </div>
        );
    }
}

export default NoMatch;
