import React, { Component } from 'react';

class NoMatch extends Component {
    render() {
        return (
            <div className="row">
                <div className="col-md-12">
                    <h4>Shopping Cart page</h4>
                </div>
            </div>
        );
    }
}

export default NoMatch;
