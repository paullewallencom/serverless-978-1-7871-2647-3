import React, { Component } from 'react';

class Header extends Component {
    render() {
        return (
            <div>
                <h2>Serverless Store</h2>
            </div>
        );
    }
}

export default Header;
