import React, { Component } from 'react';

class Footer extends Component {
    render() {
        return (
            <div>
                <h6>this is a footer</h6>
            </div>
        );
    }
}

export default Footer;
