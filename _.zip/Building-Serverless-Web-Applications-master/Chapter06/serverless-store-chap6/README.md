# Configuration files

**Frontend**: src/lib/config
**Backend**: serverless.yml
