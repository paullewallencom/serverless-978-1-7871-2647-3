module.exports.saySomething = () => 'hello';
